# python version requried 2.7.18
# create environment
# Run requiremnet.txt
from flask import Flask
from flask_restplus import Api, Resource, fields
from flask import request
from datetime import datetime
from dateutil.parser import parse

app = Flask(__name__)
api = Api(app, version='1.0', title='Todo API', description='A simple Todo API')

import sqlite3

db = sqlite3.connect('todo.db')
db.execute('CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY, title TEXT, due_date DATE, status TEXT)')

task_model = api.model('Task', {
    'title': fields.String(required=True, description='Task title'),
    'due_date': fields.Date(description='Due date of the task'),
    'status': fields.String(enum=['Not started', 'In progress', 'Finished'], description='Task status')
})

class TaskResource(Resource):
    @api.marshal_with(task_model)
    def get(self, task_id):
        # Retrieve task from the database
        db = sqlite3.connect('todo.db')
        cursor = db.cursor()
        cursor.execute("SELECT * FROM tasks WHERE id = ?", (task_id,))
        task = cursor.fetchone()
        db.close()

        if task:
            return {
                'id': task[0],
                'title': task[1],
                'due_date': task[2],
                'status': task[3]
            }
        else:
            api.abort(404, "Task {} not found".format(task_id))

    @api.expect(task_model)
    @api.marshal_with(task_model)
    def put(self, task_id):
        # Update task in the database
        task_data = request.json
        db = sqlite3.connect('todo.db')
        cursor = db.cursor()
        cursor.execute(
            "UPDATE tasks SET title = ?, due_date = ?, status = ? WHERE id = ?",
            (task_data['title'], task_data['due_date'], task_data['status'], task_id)
        )
        db.commit()
        db.close()

        return task_data, 200

    def delete(self, task_id):
        # Delete task from the database
        db = sqlite3.connect('todo.db')
        cursor = db.cursor()
        cursor.execute("DELETE FROM tasks WHERE id = ?", (task_id,))
        db.commit()
        db.close()

        return '', 204
    
api.add_resource(TaskResource, '/tasks/<int:task_id>')

task_model = api.model('Task', {
    'title': fields.String(required=True, description='Task title'),
    'due_date': fields.Date(description='Due date of the task'),
    'status': fields.String(enum=['Not started', 'In progress', 'Finished'], description='Task status')
})


api.add_resource(TaskResource, '/tasks/<int:task_id>')

@api.route('/due')
class DueTasks(Resource):
    @api.doc(params={'due_date': 'Due date in yyyy-mm-dd format'})
    @api.marshal_with(task_model, as_list=True)
    def get(self):
        # Parse the due_date parameter as a date
        due_date_param = api.payload.get('due_date')
        due_date = None
        try:
            due_date = parse(due_date_param).date()
        except Exception as e:
            api.abort(400, "Invalid due_date format. Use yyyy-mm-dd.")

        # Query and return tasks due on the specified date
        db = sqlite3.connect('todo.db')
        cursor = db.cursor()
        cursor.execute("SELECT * FROM tasks WHERE due_date = ?", (due_date,))
        tasks = cursor.fetchall()
        db.close()

        return [{
            'id': task[0],
            'title': task[1],
            'due_date': task[2],
            'status': task[3]
        } for task in tasks]

@api.route('/overdue')
class OverdueTasks(Resource):
    @api.marshal_with(task_model, as_list=True)
    def get(self):
        # Get the current date
        current_date = datetime.now().date()

        # Query and return overdue tasks
        db = sqlite3.connect('todo.db')
        cursor = db.cursor()
        cursor.execute("SELECT * FROM tasks WHERE due_date < ? AND status != 'Finished'", (current_date,))
        overdue_tasks = cursor.fetchall()
        db.close()

        return [{
            'id': task[0],
            'title': task[1],
            'due_date': task[2],
            'status': task[3]
        } for task in overdue_tasks]


@api.route('/finished')
class FinishedTasks(Resource):
    @api.marshal_with(task_model, as_list=True)
    def get(self):
        # Query and return finished tasks
        db = sqlite3.connect('todo.db')
        cursor = db.cursor()
        cursor.execute("SELECT * FROM tasks WHERE status = 'Finished'")
        finished_tasks = cursor.fetchall()
        db.close()

        return [{
            'id': task[0],
            'title': task[1],
            'due_date': task[2],
            'status': task[3]
        } for task in finished_tasks]

if __name__ == '__main__':
    app.run(debug=True)
